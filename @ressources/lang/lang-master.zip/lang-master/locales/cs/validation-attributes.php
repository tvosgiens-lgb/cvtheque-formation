<?php

return [
    'attributes' => [
        'password' => 'heslo',
    ],
];
