<?php

return [
    'attributes' => [
        'image'                   => 'تصویر',
        'result_text_under_image' => 'تصویر کے تحت نتیجے کا متن',
        'short_text'              => 'مختصر متن',
        'test_description'        => 'ٹیسٹ کی تفصیلات',
        'test_locale'             => 'زبان',
        'test_name'               => 'ٹیسٹ کا نام',
    ],
];
