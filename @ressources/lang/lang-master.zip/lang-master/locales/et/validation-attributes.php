<?php

return [
    'attributes' => [
        'image'                   => 'Pilt',
        'result_text_under_image' => 'Tulemuse tekst pildi all',
        'short_text'              => 'Lühitekst',
        'test_description'        => 'Testi kirjeldus',
        'test_locale'             => 'Keel',
        'test_name'               => 'Testi nimi',
    ],
];
