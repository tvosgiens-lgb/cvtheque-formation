<?php

return [
    'attributes' => [
        'image'                   => 'Picha',
        'result_text_under_image' => 'Maandishi ya matokeo chini ya picha',
        'short_text'              => 'Maandishi mafupi',
        'test_description'        => 'Maelezo ya jaribio',
        'test_locale'             => 'Lugha',
        'test_name'               => 'Jina la jaribio',
    ],
];
