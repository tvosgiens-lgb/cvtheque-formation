<?php

return [
    'attributes' => [
        'name'     => 'név',
        'password' => 'jelszó',
    ],
];
